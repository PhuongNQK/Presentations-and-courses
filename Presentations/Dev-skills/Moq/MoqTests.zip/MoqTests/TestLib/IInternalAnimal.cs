﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestLib
{
    /// <summary>
    /// The main internal interface we want to mock. It provides:
    /// <para>- A read-only bool property</para>
    /// <para>- A parameterless method that returns void</para>
    /// </summary>
    internal interface IInternalAnimal
    {
        bool CanRun { get; }

        void Run();
    }
}
