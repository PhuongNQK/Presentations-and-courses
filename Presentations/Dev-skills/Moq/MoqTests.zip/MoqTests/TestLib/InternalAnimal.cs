﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestLib
{
    /// <summary>
    /// An internal abstract class that implements <see cref="IInternalAnimal"/>, and provides:
    /// <para>- 2 parameterized constructors</para>
    /// <para>- A non-overridable member, i.e. the Name property</para>
    /// <para>- An abstract member, i.e. the CanRun property, and a virtual member, i.e. the Run method. Both are overridable.</para>
    /// </summary>
    internal abstract class InternalAnimal: IInternalAnimal
    {
        public InternalAnimal(string name)
        {
            this.Name = name;
        }

        public InternalAnimal(int id)
        {
            this.Name = "InternalAnimal " + id.ToString();
        }

        public string Name { get; private set; }

        public abstract bool CanRun { get; }

        public virtual void Run() { }
    }
}
