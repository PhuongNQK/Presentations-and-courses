﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Moq;

namespace Tests.StartingExamples
{
    [TestClass]
    public class AnimalTamerTest
    {
        [TestMethod]
        public void Tame_Calls_AnimalRun_If_AnimalCanRun()
        {
            var mock = new Mock<IAnimal>();

            mock.SetupGet(animal => animal.CanRun).Returns(true);

            IAnimal mockAnimal = mock.Object;
            var tamer = new AnimalTamer();
            tamer.Tame(mockAnimal);

            mock.Verify(animal => animal.Run());
        }

        [TestMethod]
        public void Tame_DoesNotCall_AnimalRun_If_AnimalCanNotRun()
        {
            var mock = new Mock<IAnimal>();

            mock.SetupGet(animal => animal.CanRun).Returns(false);
            
            IAnimal mockAnimal = mock.Object;
            var tamer = new AnimalTamer();
            tamer.Tame(mockAnimal);

            mock.Verify(animal => animal.Run(), Times.Never());            
        }
    }

    #region Classes to mock and test

    /// <summary>
    /// The main interface we want to mock. It provides:
    /// <para>- A read-only bool property</para>
    /// <para>- A parameterless method that returns void</para>
    /// </summary>
    public interface IAnimal
    {
        bool CanRun { get; }

        void Run();
    }
    
    /// <summary>
    /// The main class to test. We will test this class using 
    /// Moq-created mocks for <see cref="IAnimal"/>
    /// </summary>
    public class AnimalTamer
    {
        /// <summary>
        /// If animal.CanRun returns true, call animal.Run().
        /// </summary>
        /// <param name="animal"></param>
        public void Tame(IAnimal animal)
        {
            if (animal.CanRun)
            {
                animal.Run();
            }
        }
    }

    #endregion
}
