﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Moq;

using TestLib;

namespace Tests.Tutorial02
{
    /// <summary>
    /// Here are some main concepts:
    /// <para>- Mockable type: can be one of these: a public interface, a public abstract class, or a normal 
    /// public class (i.e. non-abstract, non-sealed class) having virtual public/protected members.</para>
    /// <para>- Mockable member: can be one of these: an interface member, an instance virtual public/protected 
    /// class member</para>
    /// </summary>
    [TestClass]
    public class Step01
    {
        [TestMethod]
        public void Test01a_CreatingMock_For_PublicTypes()
        {
            // Step 1: Create a mock builder builder
            /*
             When creating a new mock for a mockable type, we can specify the mock behavior.
             */
            var looseMockForInterface = new Mock<IAnimal>();
            var looseMockForInterface2 = new Mock<IAnimal>(MockBehavior.Default);
            var looseMockForInterface3 = new Mock<IAnimal>(MockBehavior.Loose);

            var strictMockForInterface = new Mock<IAnimal>(MockBehavior.Strict);


            var looseMockForClass = new Mock<Animal>();
            var looseMockForClass2 = new Mock<Animal>(MockBehavior.Default);
            var looseMockForClass3 = new Mock<Animal>(MockBehavior.Loose);

            var strictlooMockForClass3 = new Mock<Animal>(MockBehavior.Strict);

            /*
             When creating a new mock for a class, we can also specify the argument(s) for a specific constructor.
             */
            var mock = new Mock<Animal>(1);
            Assert.AreEqual("Animal 1", mock.Object.Name);

            var mock2 = new Mock<Animal>("Cat");
            Assert.AreEqual("Cat", mock2.Object.Name);

            var mock3 = new Mock<Animal>(MockBehavior.Strict, 1);
            Assert.AreEqual("Animal 1", mock3.Object.Name);

            var mock4 = new Mock<Animal>(MockBehavior.Loose, "Cat");
            Assert.AreEqual("Cat", mock4.Object.Name);
            
            /*
             We can also specify some other options
             */
            var mock5 = new Mock<Animal>(MockBehavior.Loose, 1);
            mock5.CallBase = true;
            mock5.DefaultValue = DefaultValue.Mock;// Default value is DefaultValue.Empty
        }

        /// <summary>
        /// This test is similar to the above, with IAnimal and Animal being replaced by IInternalAnimal and InternalAnimal.
        /// </summary>
        [TestMethod]
        public void Test01b_CreatingMock_For_InternalTypes()
        {
            // Step 1: Create a mock builder builder
            /*
             When creating a new mock for a mockable type, we can specify the mock behavior.
             */
            var looseMockForInterface = new Mock<IInternalAnimal>();
            var looseMockForInterface2 = new Mock<IInternalAnimal>(MockBehavior.Default);
            var looseMockForInterface3 = new Mock<IInternalAnimal>(MockBehavior.Loose);

            var strictMockForInterface = new Mock<IInternalAnimal>(MockBehavior.Strict);


            var looseMockForClass = new Mock<InternalAnimal>();
            var looseMockForClass2 = new Mock<InternalAnimal>(MockBehavior.Default);
            var looseMockForClass3 = new Mock<InternalAnimal>(MockBehavior.Loose);

            var strictlooMockForClass3 = new Mock<InternalAnimal>(MockBehavior.Strict);

            /*
             When creating a new mock for a class, we can also specify the argument(s) for a specific constructor.
             */
            var mock = new Mock<InternalAnimal>(1);
            Assert.AreEqual("InternalAnimal 1", mock.Object.Name);

            var mock2 = new Mock<InternalAnimal>("Cat");
            Assert.AreEqual("Cat", mock2.Object.Name);

            var mock3 = new Mock<InternalAnimal>(MockBehavior.Strict, 1);
            Assert.AreEqual("InternalAnimal 1", mock3.Object.Name);

            var mock4 = new Mock<InternalAnimal>(MockBehavior.Loose, "Cat");
            Assert.AreEqual("Cat", mock4.Object.Name);

            /*
             We can also specify some other options
             */
            var mock5 = new Mock<InternalAnimal>(MockBehavior.Loose, 1);
            mock5.CallBase = true;
            mock5.DefaultValue = DefaultValue.Mock;// Default value is DefaultValue.Empty
        }

        [TestMethod]
        public void Test01c_CreatingMock_UsingRepository()
        {
            // Step 1: Create a mock builder
            /*
             Note: Although all are created via strictRepository,
             - strictMock1 and strictMock2 are created using the behavior set to strictRepository
             - strictMock3 is created using a different behavior
             */
            var strictRepository = new MockRepository(MockBehavior.Strict);
            var strictMock1 = strictRepository.Create<IAnimal>();
            Assert.AreEqual(MockBehavior.Strict, strictMock1.Behavior);
            var strictMock2 = strictRepository.Create<Animal>(1);
            Assert.AreEqual(MockBehavior.Strict, strictMock2.Behavior);
            var strictMock3 = strictRepository.Create<Animal>(MockBehavior.Loose, "LooseAnimal");
            Assert.AreEqual(MockBehavior.Loose, strictMock3.Behavior);

            // Step 2 (optional): Set up mock behavior (or expectations)

            // Step 3: Use the mock object
            /*
             Because strictMock1 and strictMock2 have Strict behavior, they throw a MockException
             when Run() is called.
             */
            TestUtils.AssertException<MockException>(() => strictMock1.Object.Run());
            TestUtils.AssertException<MockException>(() => strictMock2.Object.Run());
            strictMock3.Object.Run();
        }

        [TestMethod]
        public void Test01d_CreatingMultiMock()
        {
            // Step 1: Create mock builders, each for an interface
            var animalMock = new Mock<IAnimal>();
            var disposableAnimalMock = animalMock.As<IDisposable>();

            // Step 2 (optional): Set up mock behavior (or expectations), separately by mock builders
            animalMock.SetupGet(animal => animal.CanRun).Returns(true);

            disposableAnimalMock.Setup(animal => animal.Dispose()).Verifiable();

            // Step 3: Use the mock objects
            /*
             Although we have to use different mock builders to set up expectations for different interfaces, 
             the mock objects returned by those builders are actually the same instance.
             */
            Assert.AreNotSame(animalMock, disposableAnimalMock);
            
            IAnimal theAnimal = animalMock.Object;
            IDisposable disposableAnimal = disposableAnimalMock.Object;
            IAnimal castedAnimal = (IAnimal)disposableAnimal;            

            Assert.AreSame(theAnimal, disposableAnimal);
            Assert.IsTrue(theAnimal.CanRun);
            Assert.IsTrue(castedAnimal.CanRun);// Our expectation for CanRun with animalMock is effective with disposableAnimalMock, too.

            // Step 4 (optional): Verify that our expectations are met
            /*
             Again, because different mock builders we created in step 1 return the same mock object, we can use the
             mock object of any builder in steps 3 and 4. That's why animalMock.Verify() can throw a MockVerificationException 
             relating to Dispose() when no setup for Dispose() is possible on animalMock.
             */
            TestUtils.AssertException(() => animalMock.Verify(), "Moq.MockVerificationException");
            TestUtils.AssertException(() => disposableAnimalMock.Verify(), "Moq.MockVerificationException");
        }

        [TestMethod]
        public void Test01e_CreatingMocks_OfTheSameType()
        {
            // Step 1: Create mock builders
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)

            // Step 3: Use the mock objects
            /*
             Different mock builders of the same type will return different mock objects.
             */
            Assert.AreNotSame(mock.Object, mock2.Object);
        }

        [TestMethod]
        public void Test01f_StrictBehavior()
        {
            // Step 1: Create a mock builder
            /*
             If we create a mock with strict behavior, then we have to specifically set up
             any member that we will call. Otherwise, a MockException is thrown.
             */
            var mock = new Mock<IAnimal>(MockBehavior.Strict);

            // Step 2 (optional): Set up mock behavior (or expectations)

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            TestUtils.AssertException<MockException>(() => theAnimal.Run());
        }
    }



    #region Classes to mock and test

    /// <summary>
    /// The main interface we want to mock. It provides:
    /// <para>- A read-only bool property</para>
    /// <para>- A parameterless method that returns void</para>
    /// </summary>
    public interface IAnimal
    {
        bool CanRun { get; }

        void Run();
    }

    /// <summary>
    /// An abstract class that implements <see cref="IAnimal"/>, and provides:
    /// <para>- 2 parameterized constructors</para>
    /// <para>- A non-overridable member, i.e. the Name property</para>
    /// <para>- An abstract member, i.e. the CanRun property, and a virtual member, i.e. the Run method. Both are overridable.</para>
    /// </summary>
    public abstract class Animal : IAnimal
    {
        public Animal(string name)
        {
            this.Name = name;
        }

        public Animal(int id)
        {
            this.Name = "Animal " + id.ToString();
        }

        public string Name { get; private set; }

        public abstract bool CanRun { get; }

        public virtual void Run() { }
    }

    #endregion
}
