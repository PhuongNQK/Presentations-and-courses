﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Moq;

namespace Tests.Tutorial04
{
    [TestClass]
    public class Step03
    {
        [TestMethod]
        public void Test01_UseMockInDirectly()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal>();
            var tamer = new AnimalTamer();

            // Step 2 (optional): Set up mock behavior (or expectations)
            mock.SetupAllProperties();
            mock.SetupGet(animal => animal.CanRun).Returns(true);

            mock2.SetupAllProperties();
            mock2.SetupGet(animal => animal.CanRun).Returns(false);

            // Step 3: Use the mock
            /*
             Here are some notes:
             - First, as a reminder, the 'mock' variable refers to the builder that builds an object which implements 
             the interface we want to mock, and mock.Object actually refers to that object.
             - Second, we can use a mock object directly (in few cases) or indirectly (in most cases). Using a mock 
             object directly means "Calling its member and check for the changes". Using a mock object indirectly means 
             "Pass it to another object X, call X's member(s) and check for the changes". Also noted that we don't always 
             have to check for the changes.
              
             Because a mock object is mainly used indirectly, we will focus on that. In the following example, we expect 
             that tamer.Tame() will do as documented.
             */
            IAnimal theAnimal = mock.Object;
            theAnimal.Name = "Demo";
            tamer.Tame(theAnimal);            
            Assert.AreEqual("Tamed Demo", theAnimal.Name);

            IAnimal theAnimal2 = mock2.Object;
            theAnimal2.Name = "Demo2";
            tamer.Tame(theAnimal2);
            Assert.AreEqual("Demo2", theAnimal2.Name);
        }

        [TestMethod]
        public void Test02_UseMockDirectly()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            mock.SetupAllProperties();
            mock.SetupGet(animal => animal.CanRun).Returns(true);

            // Step 3: Use the mock
            /* 
               We may need to use mocks directly when we're testing a mocking framework, like we're doing now.
             */
            IAnimal theAnimal = mock.Object;
            theAnimal.Name = "Demo";
            Assert.AreEqual("Demo", theAnimal.Name);
            Assert.IsTrue(theAnimal.CanRun);
        }
    }

    #region Classes to mock and test

    /// <summary>
    /// The main interface we want to mock. It provides:
    /// <para>- A read-only bool property</para>
    /// <para>- A read-write string property (string is a primitive type)</para>
    /// <para>- A read-write IAnimal property (IAnimal is not a primitive type)</para>
    /// <para>- A parameterless method that returns void</para>
    /// </summary>
    public interface IAnimal
    {
        bool CanRun { get; }

        string Name { get; set; }

        /// <summary>
        /// Gets or sets the animal that will be the acting partner of this animal.
        /// </summary>
        IAnimal Partner { get; set; }

        /// <summary>
        /// Returns true if the animal can run for the specified number of seconds. 
        /// If CanRun returns false, this method should always return false.
        /// </summary>
        /// <param name="seconds"></param>
        /// <returns></returns>
        bool CanRunFor(int seconds);

        /// <summary>
        /// If CanRun returns false, this method should throw InvalidOperationException.
        /// </summary>
        void Run();

        /// <summary>
        /// Returns the time when this animal stops running. If the animal feels exhausted, it can raise
        /// the Exhausted event and return null.
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="howLong"></param>
        /// <returns></returns>
        DateTime? Run(DateTime startTime, TimeSpan howLong);

        event EventHandler<ExhaustedEventArgs> Exhausted;
    }

    public class ExhaustedEventArgs : EventArgs
    {
        public DateTime StartTime { get; private set; }
        public TimeSpan HowLong { get; private set; }
        public DateTime ExhaustedTime { get; private set; }

        public ExhaustedEventArgs(DateTime startTime, TimeSpan howLong, DateTime exhaustedTime)
        {
            this.StartTime = startTime;
            this.HowLong = howLong;
            this.ExhaustedTime = exhaustedTime;
        }
    }

    /// <summary>
    /// The main class to test. We will test this class using Moq-created mocks for <see cref="IAnimal"/>
    /// , <see cref="Animal"/>, <see cref="Cat"/>, <see cref="Dog"/>
    /// </summary>
    public class AnimalTamer
    {
        /// <summary>
        /// If animal.CanRun returns true, call animal.Run() then prefix the animal name with "Tamed".
        /// </summary>
        /// <param name="animal"></param>
        public void Tame(IAnimal animal)
        {
            if (animal.CanRun)
            {
                animal.Run();
                animal.Name = "Tamed " + animal.Name; 
            }
        }
    }

    #endregion
}
