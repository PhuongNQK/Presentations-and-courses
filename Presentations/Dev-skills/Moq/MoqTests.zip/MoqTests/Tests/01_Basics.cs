﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Moq;

namespace Tests.Tutorial01
{
    /// <summary>
    /// This test shows these points:
    /// <para>- 4 simple steps to write tests using Moq</para>
    /// <para>- We can mock an interface, an abstract class, and a normal class having virtual (or overridable) members.</para>
    /// </summary>
    [TestClass]
    public class Basics
    {
        [TestMethod]
        public void Test01_FourBasicStepsUsingMoq()
        {
            // Step 1: Create a mock builder
            /*
             The following line creates a new mock with default mock behavior - MockBehavior.Loose
             (Loose means 'never throws exception, and returns proper default values for invocations
             that don't have a corresponding setup').
             Because we are mocking an interface, which has no constructor, we don't have to pass
             any arguments to the constructor of Mock<>.
             */
            var mock = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             We expect that:
             - When CanRun is called, it returns true
             - A call to Run() is verifiable, i.e. we can verify later that Run() has been called and 
             has been called the way we want
             */
            mock.Setup(animal => animal.CanRun).Returns(true);
            mock.Setup(animal => animal.Run()).Verifiable();

            // Step 3: Use the mock object
            /*
             The 'mock' variable does not refer to an object that implements the interface we want to mock, 
             but it refers to the builder that builds an object that implements the interface, which is 
             accessible via mock.Object.
             */
            IAnimal mockAnimal = mock.Object;
            Assert.IsTrue(mockAnimal.CanRun);
            var tamer = new AnimalTamer();
            tamer.Tame(mockAnimal);

            // Step 4 (optional): Verify that our expectations are met
            /*
             In this case, verify that Run() has been called once.
             */
            mock.Verify();
        }

        [TestMethod, ExpectedException(typeof(MockException))]
        public void Test02_WronglySetup_Will_ThrowMockException()
        {
            // Step 1: Create a mock builder
            /*
             This time we create a mock using a specified behavior - MockBehavior.Strict (Strict means
             'always throws exception for invocations that don't have a corresponding setup').
             Because we are mocking an abstract class whose constructor requires a parameter, we have 
             to pass a corresponding argument to the constructor of Mock<>.
             */
            var mock = new Mock<Animal>(MockBehavior.Strict, "Animal A");

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Here we deliberately don't set up expection for calls to Run(), which will lead to an exception
             at the last line in this test. (Note: If we used MockBehavior.Loose, the exception wouldn't occur)
             Also note that we can mock an abstract member like CanRun.
             */
            mock.Setup(animal => animal.CanRun).Returns(true);

            // Step 3: Use the mock object
            Animal mockAnimal = mock.Object;
            Assert.AreEqual("Animal A", mockAnimal.Name);
            var tamer = new AnimalTamer();
            tamer.Tame(mockAnimal);
        }

        [TestMethod, ExpectedException(typeof(NotSupportedException))]
        public void Test03_MockingSealedClass_Will_ThrowException()
        {
            // Step 1: Create a mock builder
            /*
             This time we try to mock a sealed class and get NotSupportedException right from step 1.
             */
            var mock = new Mock<Dog>();
        }

        [TestMethod, ExpectedException(typeof(NotSupportedException))]
        public void Test04_MockingNonOverridableMember_Will_ThrowException()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<Animal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             When we try to mock an overridable member like Name, we got NotSupportedException immediately.
             */
            mock.SetupGet(animal => animal.Name).Returns("Non-overridable");
        }

        [TestMethod]
        public void Test05_NeedNotCallVerify_If_NoVerifiableSetup()
        {
            // Step 1: Create a mock builder
            /*
             Which behavior does not matter.
             */
            var mock = new Mock<Cat>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Note that we have no verifiable setups.
             */
            mock.Setup(animal => animal.CanRun).Returns(true);
            mock.Setup(animal => animal.Run());

            // Step 3: Use the mock object
            Cat mockAnimal = mock.Object;
            var tamer = new AnimalTamer();
            tamer.Tame(mockAnimal);

            // Step 4 (optional): Verify that our expectations are met
            /* 
               Because we have no verifiable expectations, we don't need to call mock.Verify().
               To be more exact, we don't have to call Verify() if we don't need to make sure whether 
               our setups in step 2 have been called or not.
             */
        }

        [TestMethod]
        public void Test06a_Verify_OnlyAffects_VerifiableSetups()
        {
            // Step 1: Create a mock builder
            /*
             Which behavior does not matter.
             */
            var mock = new Mock<Cat>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             We expect that:
             - A call to CanRun is verifiable. When CanRun is called, it returns false.
             - A call to Run() is not verifiable.
             */
            mock.Setup(animal => animal.CanRun).Returns(false).Verifiable();
            mock.Setup(animal => animal.Run());

            // Step 3: Use the mock object
            Cat mockAnimal = mock.Object;
            Assert.IsFalse(mockAnimal.CanRun);
            var tamer = new AnimalTamer();
            tamer.Tame(mockAnimal);// Because mockAnimal.CanRun returns false, this call to Tame() won't entail a call to mockAnimal.Run()

            // Step 4 (optional): Verify that our expectations are met
            /*
             We want to verify that CanRun has been called.
             */
            mock.Verify();
        }

        /// <summary>
        /// This test is similar to <see cref="Test06a_Verify_OnlyAffects_VerifiableSetups"/> with a small difference in step 2
        /// , which leads to a verification exception when Verify() is called.
        /// </summary>
        [TestMethod]
        public void Test06b_Verify_OnlyAffects_VerifiableSetups_WithException()
        {
            // Step 1: Create a mock builder
            /*
             Which behavior does not matter.
             */
            var mock = new Mock<Cat>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             We expect that:
             - A call to CanRun is verifiable. When CanRun is called, it returns false.
             - A call to Run() is verifiable, too.
             */
            mock.Setup(animal => animal.CanRun).Returns(false).Verifiable();
            mock.Setup(animal => animal.Run()).Verifiable();

            // Step 3: Use the mock object
            Cat mockAnimal = mock.Object;
            Assert.IsFalse(mockAnimal.CanRun);
            var tamer = new AnimalTamer();
            tamer.Tame(mockAnimal);// Because mockAnimal.CanRun returns false, this call to Tame() won't entail a call to mockAnimal.Run()

            // Step 4 (optional): Verify that our expectations are met
            /*
             We want to verify that CanRun and Run() have been called. But we get an exception because Run() has not been called.
             */
            TestUtils.AssertException(() => mock.Verify(), "Moq.MockVerificationException");
        }

        [TestMethod]
        public void Test07_Mock_Replaces_ExistingImplementation_ByDefault()
        {
            // Step 1: Create a mock builder
            /*
             Here we use MockBehavior.Loose to avoid explicit setups.
             */
            var mock = new Mock<Cat>(MockBehavior.Loose);

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             If we used MockBehavior.Strict above, we should uncomment these lines to achieve the same effect, that is:
             - The current implementation of CanRun returns true, but here we want it to return false.
             - The current implementation of Run() throws an exception, but here it won't because it is replaced.
             */
            // mock.Setup(animal => animal.CanRun).Returns(false);
            // mock.Setup(animal => animal.Run());

            // Step 3: Use the mock object
            Cat mockAnimal = mock.Object;
            Assert.IsFalse(mockAnimal.CanRun);
            mockAnimal.Run();// No exception thrown
        }

        [TestMethod]
        public void Test08_Mock_Allows_ReuseOf_ExistingImplementation_ViaCallBaseProperty()
        {
            // Step 1: Create a mock builder
            /*
             Here we have to use MockBehavior.Loose so that mock.CallBase = true will have the effect we want.
             Behind the scenes, Moq uses DynamicCastle to create a proxy that inherits or implements the class/interface 
             we specify. 
             - If CallBase = false, that proxy will replace the existing implementations for all mockable members
             with the corresponding setups or Moq default implementations. 
             - If CallBase = true, that proxy will try to use one of these in order:
                + The corresponding setups 
                + The existing implementations for all mockable members                
                + Moq default implementations
             */
            var mock = new Mock<Cat>(MockBehavior.Loose);
            mock.CallBase = true;

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Here we want to reuse the existing implementations of CanRun and Run(), which are:
             - CanRun returns true
             - Run() throws a NotImplementedException
             */

            // Step 3: Use the mock object
            Cat mockAnimal = mock.Object;
            Assert.IsTrue(mockAnimal.CanRun);
            TestUtils.AssertException<NotImplementedException>(() => mockAnimal.Run());
        }
    }



    #region Classes to mock and test

    /// <summary>
    /// The main interface we want to mock. It provides:
    /// <para>- A read-only bool property</para>
    /// <para>- A parameterless method that returns void</para>
    /// </summary>
    public interface IAnimal
    {
        bool CanRun { get; }

        void Run();
    }

    /// <summary>
    /// An abstract class that implements <see cref="IAnimal"/>, and provides:
    /// <para>- A parameterized constructor</para>
    /// <para>- A non-overridable member, i.e. the Name property</para>
    /// <para>- An abstract member, i.e. the CanRun property, and a virtual member, i.e. the Run method. Both are overridable.</para>
    /// </summary>
    public abstract class Animal : IAnimal
    {
        public Animal(string name)
        {
            this.Name = name;
        }

        public string Name { get; private set; }

        public abstract bool CanRun { get; }

        public virtual void Run() { }
    }

    /// <summary>
    /// A normal class that extends <see cref="Animal"/>, which:
    /// <para>- Provides a parameterless constructor, and hides its parent's parameterized one</para>
    /// <para>- Always returns true for CanRun and throws NotImplementedException for Run()</para>
    /// </summary>
    public class Cat : Animal
    {
        public Cat() : base("Cat") { }

        public override bool CanRun { get { return true; } }

        public override void Run()
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// A sealed class that extends <see cref="Animal"/>, which:
    /// <para>- Provides a parameterless constructor, and hides its parent's parameterized one</para>
    /// <para>- Always returns false for CanRun and does not override Run()</para>
    /// </summary>
    public sealed class Dog : Animal
    {
        public Dog() : base("Dog") { }

        public override bool CanRun { get { return false; } }
    }

    /// <summary>
    /// The main class to test. We will test this class using Moq-created mocks for <see cref="IAnimal"/>
    /// , <see cref="Animal"/>, <see cref="Cat"/>, <see cref="Dog"/>
    /// </summary>
    public class AnimalTamer
    {
        /// <summary>
        /// If animal.CanRun returns true, call animal.Run().
        /// </summary>
        /// <param name="animal"></param>
        public void Tame(IAnimal animal)
        {
            if (animal.CanRun)
            {
                animal.Run();
            }
        }
    }

    #endregion
}
