﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Moq;
using Moq.Protected;

namespace Tests.Tutorial03
{
    [TestClass]
    public class Step02
    {
        [TestMethod]
        public void Test01a_GeneralSetup_For_DefaultReturnValues()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             We can set up the same expectations for several mockable members.
             For example, we expect that:
             - The default return value for bool type is true.
             - The default return value for int type is 3.
             - The default return value for DateTime? type is DateTime(2011, 03, 20).
             */
            mock.SetReturnsDefault<bool>(true);
            mock.SetReturnsDefault<DateTime?>(new DateTime(2011, 03, 20));

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;

            Assert.IsTrue(theAnimal.CanRun);

            TestUtils.LoopAssert(true, howLong => theAnimal.CanRunFor(howLong), 0, 99);

            Assert.AreEqual(new DateTime(2011, 03, 20), theAnimal.Run(DateTime.Now, TimeSpan.FromSeconds(100)));
        }

        [TestMethod]
        public void Test01b_GeneralSetup_For_Properties()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>()
            {
                DefaultValue = DefaultValue.Empty
            };

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Instead of calling SetupProperty() for all properties, we can issue a single call to SetupAllProperties().
             Note: DefaultValue must be DefaultValue.Empty, or an unknown exception will break the test engine.
             */
            mock.SetupAllProperties();

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            theAnimal.Name = "demo";
            Assert.AreEqual("demo", theAnimal.Name);// No exception now!

            theAnimal.Partner = theAnimal;
            Assert.AreSame(theAnimal, theAnimal.Partner);
        }

        [TestMethod]
        public void Test01c_GeneralSetup_InCombination()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>()
            {
                DefaultValue = DefaultValue.Empty
            };

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             The general setups may be combined. 
             For example, we expect that:
             - The default return value for string type is "Demo", not null by default
             - All properties should have "property behavior"
             */
            mock.SetReturnsDefault<string>("Demo");
            mock.SetReturnsDefault<bool>(true);
            mock.SetupAllProperties();

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            Assert.AreEqual("Demo", theAnimal.Name);

            TestUtils.LoopAssert(true, howLong => theAnimal.CanRunFor(howLong), 0, 99);

            theAnimal.Name = "Something";
            Assert.AreEqual("Something", theAnimal.Name);
        }

        [TestMethod]
        public void Test02a_SpecificSetup_WillOverride_GeneralSetup()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>()
            {
                DefaultValue = DefaultValue.Empty
            };

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             We can set up different expectations for different mockable members using Setup(), SetupGet(), SetupSet(). 
             Specific setups will override general setups.
             For example, we expect that:
             - All properties must have "property behavior", but Name always returns "Demo" regardless of what value it is set to,
             and setting Partner to null always throws NotImplementedException.
             */
            mock.SetupAllProperties();

            mock.SetupGet(animal => animal.Name).Returns("Demo");
            mock.SetupSet(animal => animal.Partner = null).Throws<NotImplementedException>();

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;

            theAnimal.Name = "Abc";
            Assert.AreEqual("Demo", theAnimal.Name);

            theAnimal.Partner = theAnimal;
            Assert.AreSame(theAnimal, theAnimal.Partner);
        }

        [TestMethod]
        public void Test02b_SpecificSetup_And_GeneralSetup_IssueWithSetupAllProperties()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>()
            {
                DefaultValue = DefaultValue.Empty
            };

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             If we use SetReturnsDefault() and SetupAllProperties() together plus some specific setups, 
             only SetupAllProperties() is effective. This looks like a bug of Moq, rather than the author's 
             intention not wanting us to use both at the same time.
             */
            mock.SetReturnsDefault<bool>(true);
            mock.SetupAllProperties();

            mock.SetupSet(animal => animal.Partner = null).Throws<NotImplementedException>();
            mock.Setup(animal => animal.CanRunFor(100)).Returns(true);

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;

            theAnimal.Name = "Abc";
            Assert.AreEqual("Abc", theAnimal.Name);

            Assert.IsFalse(theAnimal.CanRun);
            // OR: TestUtils.AssertBugOrUnexpectedCase(true, theAnimal.CanRun);

            Assert.IsFalse(theAnimal.CanRunFor(10));
            // OR: TestUtils.AssertBugOrUnexpectedCase(true, theAnimal.CanRunFor(10));

            Assert.IsTrue(theAnimal.CanRunFor(100));
        }

        [TestMethod]
        public void Test03a_SpecificSetup_Expectations()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Again, we can set up expectations for individual mockable members using Setup(), SetupGet(), SetupSet()
             , SetupProperty(). 
             What kinds of expectations? - Well, we can expect a member to return some value or throw an exception,
             depending on the passed arguments. In case the member does not throw an exception, we can further expect 
             the call to trigger some callback or, if it is a set property, to raise some event. Finally, we can mark 
             an expectation as verifiable or not, which will be used in step 4.
             In this example, we expect that:
             - All properties must have "property behavior"
             - Property CanRun always returns "true"
             - Setting the property Partner to null will throw ArgumentNullException. Setting it to any non-null
             value will raise the Exhausted event.             
             - If we pass 100 to CanRunFor(), it will return false. If we pass a value between 0 and 99 (including
             0 and 99) or larger than 100, it will return true.
             */
            mock.SetupAllProperties();

            mock.SetupGet(animal => animal.CanRun).Returns(true);

            mock.SetupSet(animal => animal.Partner = null).Throws<ArgumentNullException>();
            mock.SetupSet(animal => animal.Partner = It.Is<IAnimal>(value => value != null)).Raises(animal => animal.Exhausted += null, new ExhaustedEventArgs(DateTime.Now, TimeSpan.FromMilliseconds(10), DateTime.Now));

            mock.Setup(animal => animal.CanRunFor(100)).Returns(false);
            mock.Setup(animal => animal.CanRunFor(It.IsInRange(0, 99, Range.Inclusive))).Returns(true);
            mock.Setup(animal => animal.CanRunFor(It.Is<int>(value => value > 100))).Returns(true);
            /*
             Of course, we can use:
                mock.Setup(animal => animal.CanRunFor(It.Is<int>(value => (value >= 0 && value <=99) || value > 100))).Returns(true);
             to replace the above 2 lines, but I want to demonstrate different available methods. 
             BTW, do you see that we can specify multiple parameters overloads?
            */

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;

            theAnimal.Name = "Abc";
            Assert.AreEqual("Abc", theAnimal.Name);

            Assert.IsTrue(theAnimal.CanRun);

            TestUtils.AssertException<ArgumentNullException>(() => theAnimal.Partner = null);

            int counter = 0;
            theAnimal.Exhausted += new EventHandler<ExhaustedEventArgs>((sender, e) => { counter++; });
            theAnimal.Partner = theAnimal;
            Assert.AreEqual(1, counter);

            Assert.IsFalse(theAnimal.CanRunFor(100));
            TestUtils.LoopAssert(true, howLong => theAnimal.CanRunFor(howLong), 0, 99);
            TestUtils.LoopAssert(true, howLong => theAnimal.CanRunFor(howLong), 101, 200);
            Assert.IsFalse(theAnimal.CanRunFor(-1));
        }

        [TestMethod]
        public void Test03b_SpecificSetup_Expectations_WithProperty()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();

            /*
             Before we go on, we want to make sure that we can now set a value to the Name property, but we
             can not get it back, simply because it's not saved.
             */
            TestUtils.AssertException<AssertFailedException>(() =>
            {
                mock.Object.Name = "demo";
                Assert.AreEqual("demo", mock.Object.Name);
            });

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             SetupProperty() can solve our problem above.
             */
            mock.SetupProperty(animal => animal.Name);

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            theAnimal.Name = "demo";
            Assert.AreEqual("demo", theAnimal.Name);// No exception now!
        }
        
        [TestMethod]
        public void Test03c_SpecificSetup_Expectations_WithOutParameters()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Moq allows setups for out parameters, and you can use different variables for setup and use. E.g.:              
                 int maxSeconds = 5;
                 mock.Setup(animal => animal.GetMaxHowLong(out maxSeconds)).Verifiable();
                 IAnimal theAnimal = mock.Object;
                 theAnimal.GetMaxHowLong(out maxSeconds);
                 Assert.AreEqual(5, maxSeconds);
             
                 int maxSeconds2;  
                 theAnimal.GetMaxHowLong(out maxSeconds2);
                 Assert.AreEqual(5, maxSeconds2);
             */
            int maxSeconds = 5;
            mock.Setup(animal => animal.GetMaxHowLong(out maxSeconds)).Verifiable();

            mock2.Setup(animal => animal.GetMaxHowLong(out maxSeconds)).Verifiable();

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            theAnimal.GetMaxHowLong(out maxSeconds);
            Assert.AreEqual(5, maxSeconds);

            maxSeconds = 10;
            int maxSeconds2;
            IAnimal theAnimal2 = mock2.Object;
            theAnimal2.GetMaxHowLong(out maxSeconds2);
            Assert.AreEqual(5, maxSeconds2); // Can you explain why maxSeconds2 is not 10?

            // Step 4 (optional): Verify that our expectations are met
            mock.Verify();
            mock2.Verify();
        }

        [TestMethod]
        public void Test03d_SpecificSetup_Expectations_WithRefParameters()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Moq also allows setups for ref parameters, but make sure you use the same variable for setup and use
             if you want to verify the calls.
             */
            string name = "Demo";
            mock.Setup(animal => animal.GetName(ref name)).Verifiable();

            mock2.Setup(animal => animal.GetName(ref name)).Verifiable();

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            theAnimal.GetName(ref name);
            Assert.AreEqual("Demo", name);

            string name2 = null;
            IAnimal theAnimal2 = mock2.Object;
            theAnimal2.GetName(ref name2);
            Assert.IsNull(name2); // Do you see the difference between out and ref?

            // Step 4 (optional): Verify that our expectations are met
            mock.Verify();
            TestUtils.AssertException(() => mock2.Verify(), "Moq.MockVerificationException"); // Again, do you see the difference?
        }

        [TestMethod]
        public void Test03e_SpecificSetup_Expectations_WithCallback()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             In the previous example, we have seen how to expect a member to the return some value or throw an exception,
             depending on the passed arguments. We also know how to expect a set property to raise an event. Now we will
             see how to set up an expectation with a callback.
             This time we expect:
             - The default return value for bool type is true, e.g. if CanRun(howLong) is not specifically set up, it
             will return true.
             - Property CanRun will return the value of a local variable named localCanRun. Each time CanRun is called 
             and returns, localCanRun is changed to the opposite value. So, if CanRun is called successively, it will 
             return different values, not only true.
             */
            mock.SetReturnsDefault<bool>(true);

            bool localCanRun = false;
            mock.SetupGet(animal => animal.CanRun).Returns(() => localCanRun).Callback(() => localCanRun = !localCanRun);

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;

            for (int index = 0; index < 100; index++)
            {
                Assert.IsFalse(localCanRun);
                Assert.AreEqual(localCanRun, theAnimal.CanRun);
                Assert.IsTrue(localCanRun); // Do you see that the value of localCanRun is flipped after each called to CanRun?
                Assert.AreEqual(localCanRun, theAnimal.CanRun);
            }

            TestUtils.LoopAssert(true, howLong => theAnimal.CanRunFor(howLong), 0, 200);
        }

        [TestMethod]
        public void Test03f_SpecificSetup_Expectations_WithVerifiable()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             If we want to make sure that our setups are called as expected, we can mark them using Verifiable(). See more 
             in file 05_Step04.cs.
             For example, we expect that:
             - Our calls to CanRun are verifiable, without caring which value they return.
             */
            mock.SetupGet(animal => animal.CanRun).Verifiable();

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;

            // Step 4 (optional): Verify that our expectations are met
            TestUtils.AssertException(() => mock.Verify(), "Moq.MockVerificationException");
        }

        [TestMethod]
        public void Test03g_SpecificSetup_Expectations_WithRecursion()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Recursive mocking refers to creating mocks for mockable members which are of mockable types. Moq enables 
             recursive mocking in a very simple manner. 
             For example, we have created an IAnimal mock and we also want to mock its Partner property as follows:
             - Partner.CanRun always returns true
             - Partner.Name always returns "Partner"
             */
            mock2.SetupGet(animal => animal.Partner.CanRun).Returns(true);
            mock2.SetupGet(animal => animal.Partner.Name).Returns("Partner");
            
            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            Assert.IsNull(theAnimal.Partner);

            IAnimal theAnimal2 = mock2.Object;
            Assert.IsNotNull(theAnimal2.Partner); // Do you see the difference? - Yes, a proper instance has been created for Partner.
            Assert.IsTrue(theAnimal2.Partner.CanRun);
            Assert.AreEqual("Partner", theAnimal2.Partner.Name);
        }

        [TestMethod]
        public void Test03h_SpecificSetup_Expectations_WithReturnSequence()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Consider a member like CanRun, which will return something when called. Suppose we expect that:
             - CanRun will successively return true, false, false, and true if it is called for the 1st, 2nd, 3rd,
             and 4th time.
             - For any successive call, CanRun will return the default value.
             If we use this:
                mock.SetupGet(animal => animal.CanRun).Returns(true);
                mock.SetupGet(animal => animal.CanRun).Returns(false);
                mock.SetupGet(animal => animal.CanRun).Returns(false);
                mock.SetupGet(animal => animal.CanRun).Returns(true);
             we won't have what we want. When we have many setups for the same member using the same argument constraints,
             only the last of them takes effect. So, the above lines are equivalent to the last line only:
                mock.SetupGet(animal => animal.CanRun).Returns(true);
             For our case, use SetupSequence().
             */
            mock.SetupSequence(animal => animal.CanRun).Returns(true).Returns(false).Returns(false).Returns(true);

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;

            Assert.IsTrue(theAnimal.CanRun);
            Assert.IsFalse(theAnimal.CanRun);
            Assert.IsFalse(theAnimal.CanRun);
            Assert.IsTrue(theAnimal.CanRun);
        }

        [TestMethod]
        public void Test03i_SpecificSetup_Expectations_WithCyclicCallSequence()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal2>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
               MockSequence is used to set up the order of calls to different mock builders, where 2 successive calls
               can not be set up for the same mock builder. (I don't know why Moq does not support setting up a sequence 
               of calls to the same mock builder.) A sequence starts with the call to its firstly-set up members.

               In this example, we expect that if IAnimal.CanRunFor(), IAnimal2.CanRun, IAnimal.Name are called in
               that sequence, then:
               - CanRunFor() will return true if it is passed a value between 1 and 10
               - CanRun will always return true
               - Name will always return "Abc"
               That sequence must also be cyclic, i.e. when such a sequence of calls is detected, the expectations
               set up for the sequence will be applied.
               Outside the sequence, CanRunFor() will return true if it is passed a value between 11 and 20,
               and return false otherwise.
               Also note that we set up CanRunFor() in the sequence before CanRunFor() outside the sequence.
             */
            var sequence = new MockSequence() { Cyclic = true };
            mock.InSequence(sequence).Setup(animal => animal.CanRunFor(It.IsInRange<int>(1, 10, Range.Inclusive))).Returns(true).Verifiable();
            mock2.InSequence(sequence).Setup(animal => animal.CanRun).Returns(true).Verifiable();
            mock.InSequence(sequence).SetupGet(animal => animal.Name).Returns("Abc").Verifiable();
            mock.Setup(animal => animal.CanRunFor(It.IsInRange<int>(11, 20, Range.Inclusive))).Returns(true).Verifiable();

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            IAnimal2 theAnimal2 = mock2.Object;

            Assert.IsFalse(theAnimal2.CanRun);      // This call to CanRun is not made in the expected sequence, so it is
                                                    // not evaluated using the sequence expectations we set up above.

            Assert.IsTrue(theAnimal.CanRunFor(10)); // The sequence starts here, with a call to its first expectation - CanRunFor()
            Assert.IsTrue(theAnimal2.CanRun);
            Assert.AreEqual("Abc", theAnimal.Name);
            
            Assert.IsTrue(theAnimal.CanRunFor(15)); // The sequence restarts here, with a call to CanRunFor(), although the arguments
                                                    // does not satisfy the expected rule (e.g. must be in the range of [1; 10]).
            Assert.IsTrue(theAnimal2.CanRun);
            Assert.AreEqual("Abc", theAnimal.Name);

            Assert.IsTrue(theAnimal.CanRunFor(1));  // The sequence restarts here, with a call to CanRunFor(). Because we're in our
                                                    // cyclic sequence, the expectation rule for CanRunFor() is used.
            Assert.IsTrue(theAnimal2.CanRun);       // Because we won't call theAnimal.Name next, the sequence will stop here. In
                                                    // other words, we're out of sequence again.

            Assert.IsFalse(theAnimal.CanRunFor(4)); // As a result, the setup for CanRunFor() in sequence is not effective. However, 
                                                    // a call to CanRunFor() still makes Moq put us back in a sequence.

            Assert.IsTrue(theAnimal.CanRunFor(5));  // That's why the expectation rule for CanRunFor() in sequence is effective here.
                                                    // Note: we can have 2 successive calls to CanRunFor() in a situation like this.
            Assert.IsTrue(theAnimal2.CanRun);
            Assert.AreEqual("Abc", theAnimal.Name);

            Assert.IsTrue(theAnimal.CanRunFor(4));  // Here, the setup for CanRunFor() in sequence is effective, because Moq thinks
                                                    // we're still in our cyclic sequence.
            Assert.IsTrue(theAnimal.CanRunFor(15)); // This call breaks the previous sequence but also signals the start of a new sequence.
            Assert.IsFalse(theAnimal.CanRunFor(5)); // And we have another 2-successive-calls-to-CanRunFor() situation.
            Assert.IsTrue(theAnimal2.CanRun);
            Assert.AreEqual("Abc", theAnimal.Name);

            Assert.IsFalse(theAnimal2.CanRun);      // The sequence is broken here, etc.

            // Step 4 (optional): Verify that our expectations are met
            mock.Verify();
        }

        [TestMethod]
        public void Test03j_SpecificSetup_Expectations_WithNonCyclicCallSequence()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal2>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*               
               In this example, we expect that if IAnimal.CanRunFor(), IAnimal2.CanRun, IAnimal.Name are called in
               that sequence, then:
               - CanRunFor() will return true if it is passed a value between 1 and 10
               - CanRun will always return true
               - Name will always return "Abc"
               That sequence is not cyclic, i.e. only the first occurrence of such a sequence of calls will be detected
               and applied the above expectations.
               Outside the sequence, CanRunFor() will return true if it is passed a value between 11 and 20,
               and return false otherwise.
               Also note that we set up CanRunFor() in the sequence before CanRunFor() outside the sequence.
             */
            var sequence = new MockSequence() { Cyclic = false };
            mock.InSequence(sequence).Setup(animal => animal.CanRunFor(It.IsInRange<int>(1, 10, Range.Inclusive))).Returns(true).Verifiable();
            mock2.InSequence(sequence).Setup(animal => animal.CanRun).Returns(true).Verifiable();
            mock.InSequence(sequence).SetupGet(animal => animal.Name).Returns("Abc").Verifiable();
            mock.Setup(animal => animal.CanRunFor(It.IsInRange<int>(11, 20, Range.Inclusive))).Returns(true).Verifiable();

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            IAnimal2 theAnimal2 = mock2.Object;

            Assert.IsFalse(theAnimal2.CanRun);      // This call to CanRun is not made in the expected sequence, so it is
                                                    // not evaluated using the sequence expectations we set up above.

            Assert.IsTrue(theAnimal.CanRunFor(10)); // The sequence starts here, with a call to its first expectation - CanRunFor()
            Assert.IsTrue(theAnimal2.CanRun);
            Assert.AreEqual("Abc", theAnimal.Name); // The sequence stops here and can not restart, because it's not cyclic.

            Assert.IsTrue(theAnimal.CanRunFor(15)); // The expectation outside the sequence is applied.
            Assert.IsFalse(theAnimal2.CanRun);
            Assert.AreNotEqual("Abc", theAnimal.Name);

            // Step 4 (optional): Verify that our expectations are met
            mock.Verify();
        }

        [TestMethod]
        public void Test03k_SpecificSetup_Expectations_WithCyclicCallSequence_And_MockOfSameType()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /* 
               The expectations in this example is identical to the above examples, with a difference
               that they are set up to one mock builder, not two.
               You will see these interesting points:
               - If Cyclic is true, a call to any expectation in the sequence will start the sequence and
               the sequence works as non-sequence, i.e. call order is not important and rules are mixed inside
               and outside sequence.
               - If Cyclic is false, a call to any expectation in the sequence will start the sequence and stop
               it immediately.
               Is it a bug of Moq?
             */
            var sequence = new MockSequence() { Cyclic = true };
            mock.InSequence(sequence).Setup(animal => animal.CanRunFor(It.IsInRange<int>(1, 10, Range.Inclusive))).Returns(true);
            mock.InSequence(sequence).SetupGet(animal => animal.CanRun).Returns(true);
            mock.InSequence(sequence).SetupGet(animal => animal.Name).Returns("Abc");
            mock.Setup(animal => animal.CanRunFor(It.IsInRange<int>(11, 20, Range.Inclusive))).Returns(true).Verifiable();

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;

            Assert.IsTrue(theAnimal.CanRunFor(11));
            Assert.AreEqual("Abc", theAnimal.Name);
            Assert.IsTrue(theAnimal.CanRun);

            Assert.IsTrue(theAnimal.CanRunFor(10));
            Assert.IsTrue(theAnimal.CanRun);
            Assert.AreEqual("Abc", theAnimal.Name);

            Assert.IsTrue(theAnimal.CanRun);
            Assert.IsTrue(theAnimal.CanRunFor(15));
            Assert.AreEqual("Abc", theAnimal.Name);
        }

        [TestMethod]
        public void Test03l_SpecificSetup_Expectations_WithCondition()
        {
            // Step 1+2: Create a mock builder and set up mock behaviors (or expectations)
            /*
             In case many of our tests share a similar logic of creating and setting up mocks, we often extract
             that logic into a parameterized method which may return different mocks depending on the passed arguments.
             Inside that method, instead of using if blocks to determine the necessary setups, we can use When().
             */
            var mock = CreateMock(false);
            var mock2 = CreateMock(true);

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            theAnimal.Name = "abc";

            IAnimal theAnimal2 = mock2.Object;
            TestUtils.AssertException<ArgumentException>(() => theAnimal2.Name = "abc");// Do you see the difference?
        }

        /// <summary>
        /// Returns a mock that may or may not throw an ArgumentException whenever the property Name is set, depending on 
        /// whether <paramref name="throwsException"/> is false or true.
        /// </summary>
        /// <param name="throwsException"></param>
        /// <returns></returns>
        private Mock<IAnimal> CreateMock(bool throwsException)
        {
            var mock = new Mock<IAnimal>();
            mock.When(() => throwsException).SetupSet(animal => animal.Name = It.IsAny<string>()).Throws(new ArgumentException());
            mock.When(() => !throwsException).SetupSet(animal => animal.Name = It.IsAny<string>());

            return mock;
        }

        [TestMethod]
        public void Test03m_SpecificSetup_Expectations_WithProtectedMembers()
        {
            // Step 1: Create a mock builder
            var animalMock = new Mock<IAnimal>();
            var tamerMock = new Mock<AnimalTamer>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Moq allows mocking protected members (provided that they are overridable, i.e. marked as virtual in C#)
             via the Protected() extension method in Moq.Protected namespace.
             In this example, we set up that:
             - animal.CanRun always returns false (so, if the real implementation of tamer.IsRunnable() is used,
             animal.Run() will never be called)
             - tamer.IsRunnable() always returns true (despite that the real implementation returns animal.CanRun)
             */
            animalMock.Setup(animal => animal.CanRun).Returns(false);

            tamerMock.Protected().Setup<bool>("IsRunnable", ItExpr.IsAny<IAnimal>()).Returns(true);

            // Step 3: Use the mock object
            IAnimal theAnimal = animalMock.Object;
            AnimalTamer theTamer = tamerMock.Object;
            theTamer.Tame(theAnimal);

            // Step 4 (optional): Verify that our expectations are met
            /*
             We verify that animal.Run() is called once, which is true only if our setup for the protected, virtual member
             tamer.IsRunnable() is effective.
             */
            animalMock.Verify(animal => animal.Run(), Times.Once());
        }

        [TestMethod]
        public void Test04a_SpecificSetup_SyntaxNotes_LambdaExpression_vs_Value()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             In the previous examples, we have seen how to set up different kinds of expectations. Now, we are going
             through some syntax notes that may help to explain why some own expectations fail to work as we think.
             The first note is make sure you can distinguish the different between a normal expression and a lambda one.
             For example, look at this:
                bool localCanRun = false;
                ...Returns(() => localCanRun)...;
             and this:
                bool localCanRun = false;
                ...Returns(localCanRun)...;
             Because the former uses a lambda expression (which will be evaluated at runtime), it will return the current 
             value of localCanRun at the time Returns() is called. On the contrary, the latter uses a normal expression
             (which will be evaluated at compile-time), it will always return the value of localCanRun at compile-time - false
             in this case.
             */
            bool localCanRun = false;
            mock.SetupGet(animal => animal.CanRun).Returns(() => localCanRun).Callback(() => localCanRun = !localCanRun);

            bool localCanRun2 = false;
            mock2.SetupGet(animal => animal.CanRun).Returns(localCanRun2).Callback(() => localCanRun2 = !localCanRun2);

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            for (int index = 0; index < 100; index++)
            {
                Assert.IsFalse(localCanRun);
                Assert.IsFalse(theAnimal.CanRun);
                Assert.IsTrue(localCanRun);

                Assert.IsTrue(theAnimal.CanRun); // Here is the difference
            }

            IAnimal theAnimal2 = mock2.Object;
            for (int index = 0; index < 100; index++)
            {
                Assert.IsFalse(localCanRun2);
                Assert.IsFalse(theAnimal2.CanRun);
                Assert.IsTrue(localCanRun2);

                Assert.IsFalse(theAnimal2.CanRun); // Here is the difference
            }
        }

        [TestMethod]
        public void Test04b_SpecificSetup_SyntaxNotes_OrderOf_ReturnsAndCallback()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Now you know that a normal expression and a lambda one are different. The next note is the order of Returns()
             and Callback() can affect the expected value in your assertion, because which is called first will run and make
             changes first.
             */
            bool localCanRun = false;
            mock.SetupGet(animal => animal.CanRun).Returns(() => localCanRun).Callback(() => localCanRun = !localCanRun);

            bool localCanRun2 = false;
            mock2.SetupGet(animal => animal.CanRun).Callback(() => localCanRun2 = !localCanRun2).Returns(() => localCanRun2);

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            for (int index = 0; index < 100; index++)
            {
                Assert.IsFalse(localCanRun);
                Assert.IsFalse(theAnimal.CanRun);
                Assert.IsTrue(localCanRun);
                Assert.IsTrue(theAnimal.CanRun);
            }

            IAnimal theAnimal2 = mock2.Object;
            for (int index = 0; index < 100; index++)
            {
                Assert.IsFalse(localCanRun2);
                Assert.IsTrue(theAnimal2.CanRun); // Do you see the difference?
                Assert.IsTrue(localCanRun2);
                Assert.IsFalse(theAnimal2.CanRun);
            }
        }

        [TestMethod]
        public void Test04c_SpecificSetup_SyntaxNotes_OrderOf_AssertionArguments()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal>();
            var mock3 = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            /*
             Not only can the order of Returns() and Callback() affect your assertion, so can the order of assertion arguments, 
             in case you use callbacks. If your callback changes a member X, and you pass X as an argument to some assertion,
             then be careful!
             In this test, mock and mock2 are set up identically with Returns() called before Callback(), while mock3 is 
             different in that Returns() is called after Callback().
             */
            bool localCanRun = false;
            mock.SetupGet(animal => animal.CanRun).Returns(() => localCanRun).Callback(() => localCanRun = !localCanRun);

            bool localCanRun2 = false;
            mock2.SetupGet(animal => animal.CanRun).Returns(() => localCanRun2).Callback(() => localCanRun2 = !localCanRun2);

            bool localCanRun3 = false;
            mock3.SetupGet(animal => animal.CanRun).Callback(() => localCanRun3 = !localCanRun3).Returns(() => localCanRun3);

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            for (int index = 0; index < 100; index++)
            {
                Assert.IsFalse(localCanRun);
                Assert.AreEqual(localCanRun, theAnimal.CanRun);
                Assert.IsTrue(localCanRun);
                Assert.AreEqual(localCanRun, theAnimal.CanRun);
            }

            IAnimal theAnimal2 = mock2.Object;
            for (int index = 0; index < 100; index++)
            {
                Assert.IsFalse(localCanRun2);
                Assert.AreNotEqual(theAnimal2.CanRun, localCanRun2); // Do you see the difference?
                Assert.IsTrue(localCanRun2);
                Assert.AreNotEqual(theAnimal2.CanRun, localCanRun2);
            }

            IAnimal theAnimal3 = mock3.Object;
            for (int index = 0; index < 100; index++)
            {
                Assert.IsFalse(localCanRun3);
                Assert.AreEqual(theAnimal3.CanRun, localCanRun3); // Do you see the difference?
                Assert.IsTrue(localCanRun3);
                Assert.AreEqual(theAnimal3.CanRun, localCanRun3);
            }
        }

        [TestMethod]
        public void Test04d_SpecificSetup_SyntaxNotes_Summary()
        {
            /*
             To summarize:
             - If you need to use runtime values to set up expectations, use lambda expressions. Otherwise, use normal expressions.
             - Depending on your needs, you may want Returns() or Callback() to be called first, but try to stick to one style.
             - You are free to choose the order of assertion arguments, but your expected and actual values should follow
             the order suggested by the framework you use to write assertions. Moreover, make sure your expressions have 
             the expected values in your assertions by using as fixed and literal values as possible.             
             */
        }
    }

    #region Classes to mock and test

    /// <summary>
    /// The main interface we want to mock. It provides:
    /// <para>- A read-only bool property</para>
    /// <para>- A read-write string property (string is a primitive type)</para>
    /// <para>- A read-write IAnimal property (IAnimal is not a primitive type)</para>
    /// <para>- A parameterless method that returns void</para>
    /// </summary>
    public interface IAnimal
    {
        bool CanRun { get; }

        string Name { get; set; }

        /// <summary>
        /// Gets or sets the animal that will be the acting partner of this animal.
        /// </summary>
        IAnimal Partner { get; set; }

        /// <summary>
        /// Returns true if the animal can run for the specified number of seconds. 
        /// If CanRun returns false, this method should always return false.
        /// </summary>
        /// <param name="seconds"></param>
        /// <returns></returns>
        bool CanRunFor(int seconds);

        /// <summary>
        /// If CanRun returns false, this method should throw InvalidOperationException.
        /// </summary>
        void Run();

        /// <summary>
        /// Returns the time when this animal stops running. If the animal feels exhausted, it can raise
        /// the Exhausted event and return null.
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="howLong"></param>
        /// <returns></returns>
        DateTime? Run(DateTime startTime, TimeSpan howLong);

        /// <summary>
        /// Returns the animal name.
        /// (This method is designed to demonstrate ref arguments.)
        /// </summary>
        /// <param name="name"></param>
        void GetName(ref string name);

        /// <summary>
        /// Returns the maximum seconds the animal can run.
        /// (This method is designed to demonstrate out arguments.)
        /// </summary>
        /// <param name="maxSeconds"></param>
        void GetMaxHowLong(out int maxSeconds);

        event EventHandler<ExhaustedEventArgs> Exhausted;
    }

    public interface IAnimal2
    {
        bool CanRun { get; }
    }

    public class ExhaustedEventArgs : EventArgs
    {
        public DateTime StartTime { get; private set; }
        public TimeSpan HowLong { get; private set; }
        public DateTime ExhaustedTime { get; private set; }

        public ExhaustedEventArgs(DateTime startTime, TimeSpan howLong, DateTime exhaustedTime)
        {
            this.StartTime = startTime;
            this.HowLong = howLong;
            this.ExhaustedTime = exhaustedTime;
        }
    }

    /// <summary>
    /// This class is designed to demonstrate that we can mock a protected member.
    /// </summary>
    public class AnimalTamer
    {
        /// <summary>
        /// If IsRunnable(animal) returns true, call animal.Run().
        /// </summary>
        /// <param name="animal"></param>
        public void Tame(IAnimal animal)
        {
            if (IsRunnable(animal))
            {
                animal.Run();
            }
        }

        protected virtual bool IsRunnable(IAnimal animal)
        {
            return animal.CanRun;
        }
    }

    #endregion
}
