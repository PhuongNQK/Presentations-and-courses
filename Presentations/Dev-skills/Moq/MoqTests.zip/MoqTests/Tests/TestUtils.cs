﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    public class TestUtils
    {
        private const string MessageShouldNotReachHere = "Should not reach here.";

        /// <summary>
        /// Asserts that when action is invoked, it will throw an exception having the specified full name.
        /// Useful when the thrown exception is not public.
        /// </summary>
        /// <param name="action"></param>
        /// <param name="exceptionFullName">Should not be the full name of the exception thrown by Assert.Fail(), i.e. "Microsoft.VisualStudio.TestTools.UnitTesting.AssertFailedException"</param>
        public static void AssertException(Action action, string exceptionFullName)
        {
            try
            {
                action.Invoke();
                Assert.Fail(MessageShouldNotReachHere);
            }
            catch (Exception ex)
            {
                Assert.AreNotEqual(MessageShouldNotReachHere, ex.Message);
                Assert.AreEqual(exceptionFullName, ex.GetType().FullName);
            }
        }

        /// <summary>
        /// Asserts that when action is invoked, it will throw an exception of the specified type.
        /// </summary>
        /// <param name="action">Should not throw the same exception thrown by Assert.Fail("Should not reach here.")</param>
        public static void AssertException<T>(Action action) where T : Exception
        {
            try
            {
                action.Invoke();
                Assert.Fail(MessageShouldNotReachHere);
            }
            catch (Exception ex)
            {
                Assert.AreEqual(typeof(T), ex.GetType());
                Assert.AreNotEqual(MessageShouldNotReachHere, ex.Message);
            }
        }

        /// <summary>
        /// Asserts that we have an unexpected case, where actualValue should be equal to expectedValue, but they turn out to be not equal.
        /// <para>For example, AssertBugOrUnexpectedCase(true, canRun) mean 'I expect canRun to be true, but due to some reason, canRun is false. So,
        /// I assert that I have an unexpected case.'</para>
        /// <para>When we've fixed all reasons leading to this unexpected case, we can replace it with normal assertions.</para>
        /// </summary>
        /// <param name="expected"></param>
        /// <param name="target"></param>
        public static void AssertBugOrUnexpectedCase(object expectedValue, object actualValue)
        {
            try
            {
                Assert.AreNotEqual(expectedValue, actualValue);
                Assert.AreNotSame(expectedValue, actualValue);
            }
            catch (AssertFailedException)
            {
                throw new AssertFailedException(string.Format("To have an unexpected case, targetValue should not be <{0}>", expectedValue));
            }
        }

        /// <summary>
        /// Loops to assert that all actual values are equal to the expected one. Each actual value is created by passing 
        /// an index between <paramref name="fromIndex"/> and <paramref name="toIndex"/> to <paramref name="actualValueMaker"/>
        /// </summary>
        /// <param name="expectedValue"></param>
        /// <param name="actualValueMaker"></param>
        /// <param name="fromIndex"></param>
        /// <param name="toIndex"></param>
        public static void LoopAssert(object expectedValue, Func<int, object> actualValueMaker, int fromIndex, int toIndex)
        {
            for (int index = fromIndex; index <= toIndex; index++)
            {
                Assert.AreEqual(expectedValue, actualValueMaker(index));
            }
        }
    }
}
