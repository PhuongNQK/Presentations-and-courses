﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Moq;

namespace Tests.Tutorial05
{
    [TestClass]
    public class Step04
    {
        [TestMethod]
        public void Test01_Verify_Introduction()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)

            // Step 3 (Skipped): Use the mock object

            // Step 4 (optional): Verify that our expectations are met
            /*
             Verifying expectations means 'making sure that they have been called and the number of calls 
             satisfies some criteria.'
             If we don't set up any expectation, calling Verify() will never throw an exception.
             If we have expectations that are not called, calling Verify() may throw a MockVerificationException.
             */
            mock.Verify();
        }

        [TestMethod]
        public void Test02_Verify_VerifiableExpectations()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            mock.SetupGet(animal => animal.CanRun).Returns(true).Verifiable();
            mock2.SetupGet(animal => animal.CanRun).Returns(true).Verifiable();

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            Assert.IsTrue(theAnimal.CanRun);

            IAnimal theAnimal2 = mock2.Object;

            // Step 4 (optional): Verify that our expectations are met
            /*
             Both mock and mock2 expect that a call to CanRun will return true and is verifiable.
             But because there is a call to mock.Object.CanRun and no call to mock2.Object.CanRun, 
             mock2.Verify() throws a MockVerificationException while mock.Verify() does not.
             */
            mock.Verify();
            TestUtils.AssertException(() => mock2.Verify(), "Moq.MockVerificationException");
        }

        [TestMethod]
        public void Test03_Verify_AllExpectations()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();
            var mock2 = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            mock.Setup(animal => animal.CanRunFor(100)).Returns(true);
            mock.SetupGet(animal => animal.CanRun).Returns(true).Verifiable();

            mock2.Setup(animal => animal.CanRunFor(100)).Returns(true);
            mock2.SetupGet(animal => animal.CanRun).Returns(true).Verifiable();

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            Assert.IsTrue(theAnimal.CanRun);

            IAnimal theAnimal2 = mock2.Object;
            Assert.IsTrue(theAnimal2.CanRun);

            // Step 4 (optional): Verify that our expectations are met
            /*
             mock and mock2 are set up identically. They both expect that:
             - A call to CanRunFor(100) will return true
             - A call to CanRun will return true and is verifiable
             Moreover, regarding mock.Object and mock2.Object, CanRun was called while CanRunFor() was not.
             
             When we call Verify(), only expectations marked Verifiable() will be verified. When
             we call VerifyAll(), all explicit setups will be verified. That's why mock2.VerifyAll() 
             throws a MockVerificationException while mock.VerifyAll() does not.
             */
            mock.Verify();
            TestUtils.AssertException(() => mock2.VerifyAll(), "Moq.MockVerificationException");
        }

        [TestMethod]
        public void Test04_Verify_SpecificExpectations()
        {
            // Step 1: Create a mock builder
            var mock = new Mock<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            mock.Setup(animal => animal.CanRunFor(100)).Returns(true);
            mock.SetupGet(animal => animal.CanRun).Returns(true);

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            Assert.IsTrue(theAnimal.CanRun);

            // Step 4 (optional): Verify that our expectations are met
            /*
             Marking an expectation using Vefifiable() will be useful if we simply call Verify(<no-args>)
             or VerifyAll() to verify several expectations at a time. Vefifiable() is not necessary 
             when we want to verify a specific expectation using Verify(<with-args>), VerifyGet(), 
             or VerifySet().
             Specific verification allows us to specify more options, such as a failure message, or the 
             number of times the expectation must have been called: never, once, exactly n times, at 
             least n times, at most n times, or between m and n times, etc.
             
             For example, we want to verify that:
             - A call to CanRun must have been called at least once.
             - A call to CanRunFor() must never have been called with any argument.
             */
            mock.VerifyGet(animal => animal.CanRun, Times.AtLeastOnce());
            mock.Verify(animal => animal.CanRunFor(It.IsAny<int>()), Times.Never());
        }

        [TestMethod]
        public void Test05_Verify_AllMocks_From_TheSameRepository()
        {
            // Step 1: Create a mock builder
            var repository = new MockRepository(MockBehavior.Loose);
            var mock = repository.Create<IAnimal>();
            var mock2 = repository.Create<IAnimal>();

            // Step 2 (optional): Set up mock behavior (or expectations)
            mock.SetupGet(animal => animal.CanRun).Returns(true);

            mock2.Setup(animal => animal.CanRunFor(100)).Returns(true);

            // Step 3: Use the mock object
            IAnimal theAnimal = mock.Object;
            Assert.IsTrue(theAnimal.CanRun);

            IAnimal theAnimal2 = mock2.Object;
            Assert.IsTrue(theAnimal.CanRun);

            // Step 4 (optional): Verify that our expectations are met
            /*
             If we created our mocks using a MockRepository, we can call Verify() or VerifyAll() on that 
             repository to verify all (verifiable) expectations that have been set up on all mocks created
             from that repository.
             
             Note: In case any expectations are not met, we will have a MockException, not MockVerificationException.
             It seems a little inconsistency, right?
             */
            TestUtils.AssertException(() => repository.VerifyAll(), "Moq.MockException"); // Can you explain why we have it?
        }
    }

    #region Classes to mock and test

    /// <summary>
    /// The main interface we want to mock. It provides:
    /// <para>- A read-only bool property</para>
    /// <para>- A read-write string property (string is a primitive type)</para>
    /// <para>- A read-write IAnimal property (IAnimal is not a primitive type)</para>
    /// <para>- A parameterless method that returns void</para>
    /// </summary>
    public interface IAnimal
    {
        bool CanRun { get; }

        string Name { get; set; }

        /// <summary>
        /// Gets or sets the animal that will be the acting partner of this animal.
        /// </summary>
        IAnimal Partner { get; set; }

        /// <summary>
        /// Returns true if the animal can run for the specified number of seconds. 
        /// If CanRun returns false, this method should always return false.
        /// </summary>
        /// <param name="seconds"></param>
        /// <returns></returns>
        bool CanRunFor(int seconds);

        /// <summary>
        /// If CanRun returns false, this method should throw InvalidOperationException.
        /// </summary>
        void Run();

        /// <summary>
        /// Returns the time when this animal stops running. If the animal feels exhausted, return null.
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="howLong"></param>
        /// <returns></returns>
        DateTime? Run(DateTime startTime, TimeSpan howLong);
    }

    #endregion
}

