﻿In this project, we use the Moq assembly from Lib\NET40.

Each tutorial tries to be independent from each other, so that readers can focus more easily.