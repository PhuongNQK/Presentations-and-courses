﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Reflection;
using System.IO;

using SysConsole = System.Console;

namespace Demo.Console
{
    class Program
    {
        static void Main(string[] args)
        {
			WriteHeaderLine("Startup path: Which one?");
            WriteLine("Environment.CurrentDirectory: {0}", Environment.CurrentDirectory);
            WriteLine();
            WriteLine("Process.GetCurrentProcess().MainModule.FileName: {0}", 
                Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName));
            WriteLine();
            WriteLine("AppDomain.CurrentDomain.BaseDirectory: {0}", AppDomain.CurrentDomain.BaseDirectory);
			WriteLine();
			WriteLine("EntryAssembly.Location: {0}", Assembly.GetEntryAssembly().Location);
			
			WriteLine();
            WriteHeaderLine("Entry assembly");
            WriteAssemblyInfo(Assembly.GetEntryAssembly());
            WriteLine();
            WriteHeaderLine("Executing assembly");
            WriteAssemblyInfo(Assembly.GetExecutingAssembly());
            WriteLine();
            WriteHeaderLine("Calling assembly");
            WriteAssemblyInfo(Assembly.GetCallingAssembly());
		
			var assembly1 = Assembly.LoadFrom("Utilities.dll");            
            WriteHeaderLine("assembly1");
            WriteAssemblyInfo(assembly1);
			
			var assembly2 = Assembly.LoadFrom("sub\\Utils.dll"); //publicKeyToken = 4f6ee6ef30da1a8d
			WriteHeaderLine("assembly2");
            WriteAssemblyInfo(assembly2);
        }

		private static void WriteAssemblyInfo(Assembly assembly)
        {
            WriteLine("Assembly: {0}", assembly.FullName);
            WriteLine("Location: {0}", assembly.Location);
            WriteLine("CodeBase: {0}", assembly.CodeBase);
        }

        private static void WriteLine()
        {
            SysConsole.WriteLine();
        }
		
        private static void WriteLine(string pattern, params object[] args)
        {
            SysConsole.WriteLine(pattern, args);
        }

        private static void WriteHeaderLine(string pattern, params object[] args)
        {
            SysConsole.WriteLine("----- " + pattern + " -----", args);
        }
    }
}
