﻿namespace Demo.CSLib
{
	public static class Utils
	{
		public static string Greet(string name)
		{
			return "Hello " + name;
		}
	}
}