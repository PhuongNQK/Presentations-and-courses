﻿namespace Demo.CSLib
{
	public static class Utilities
	{
		public static string Greet(string name)
		{
			return "Hello " + name;
		}
	}
}