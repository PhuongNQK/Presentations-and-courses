﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using Demo.CSLib;

using SysConsole = System.Console;

namespace Demo.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine(Utilities.Greet("John"));
            WriteLine(Utils.Greet("Mary"));
        }

        private static void WriteLine(string pattern, params object[] args)
        {
            SysConsole.WriteLine(pattern, args);
        }

        private static void WriteHeaderLine(string pattern, params object[] args)
        {
            SysConsole.WriteLine("----- " + pattern + " -----", args);
        }
    }
}
