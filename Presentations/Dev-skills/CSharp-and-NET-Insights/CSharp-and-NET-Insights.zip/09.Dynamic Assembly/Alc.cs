﻿//// file    : alc.cs
// compile : csc alc.cs

namespace ArithLang
{

    using System;
    using System.IO;
    using System.Threading;
    using System.Reflection;
    using System.Reflection.Emit;

    class ALC
    {

        public static void Main(string[] args)
        {
            Console.WriteLine("Arithmetic Language Compiler...");
            if (args.Length != 1)
            {
                Console.WriteLine("usage: alc progname.al");
                return;
            }
            new ALC(args[0]); // launch AL compiler
        }

        public ALC(string filePath)
        {

            inFile = filePath;
            outFile = Path.ChangeExtension(inFile, "exe");

            int lineNum = 0;
            string line = "";
            StreamReader sr = null;

            try
            {
                sr = File.OpenText(inFile);  // open source file
                init(); // create new assembly

                char[] separator = { ' ' };
                while ((line = sr.ReadLine()) != null)
                {

                    lineNum++;
                    string[] tokens = line.Trim().ToLower().Split(separator);

                    if (tokens[0].Equals("add"))
                    {
                        doAddStatement(tokens[1]);
                        continue;
                    }

                    if (tokens[0].Equals("sub"))
                    {
                        doSubStatement(tokens[1]);
                        continue;
                    }

                    if (tokens[0].Equals("print"))
                    {
                        doPrintStatement();
                        continue;
                    }

                    if (tokens[0].Equals("reset"))
                    {
                        doResetStatement();
                        continue;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("ERROR LINE({0}): {1}", lineNum, line);
                Console.WriteLine(e.Message);
                return;
            }
            finally
            {
                if (sr != null) sr.Close();
            }
            save();
            Console.WriteLine("Done!");
        }

        private void init()
        {

            // create dynamic assembly...
            AssemblyName asmName = new AssemblyName();
            asmName.Name = "AlcAsm";
            alcAsm = Thread.GetDomain().DefineDynamicAssembly(
              asmName,
              AssemblyBuilderAccess.Save
            );

            // create module in this assembly...
            alcMod = alcAsm.DefineDynamicModule(
              "AlcMod",
              outFile
            );

            // create class in this module...
            alcCls = alcMod.DefineType(
              "AlcCls",
              TypeAttributes.Public
            );

            // create AlcCls class constructor...
            ConstructorBuilder alcCon = alcCls.DefineConstructor(
              MethodAttributes.Public | MethodAttributes.HideBySig,
              CallingConventions.Standard,
              new Type[0]
            );

            // generate constructor IL...
            ILGenerator conILG = alcCon.GetILGenerator();
            ConstructorInfo conObj =
              typeof(object).GetConstructor(new Type[0]);
            conILG.Emit(OpCodes.Ldarg_0);
            conILG.Emit(OpCodes.Call, conObj);
            conILG.Emit(OpCodes.Ret);

            // create AlcCls.Main() method...
            MethodBuilder mainMethod = alcCls.DefineMethod(
              "Main",
              MethodAttributes.Public |
              MethodAttributes.Static |
              MethodAttributes.HideBySig,
              Type.GetType("void"),
              null);

            // set Main as program entrypoint...
            alcAsm.SetEntryPoint((MethodInfo)mainMethod);

            // generate IL for Main.
            alcILG = mainMethod.GetILGenerator();

            // create local integer variable...
            LocalBuilder v_0 = alcILG.DeclareLocal(
              Type.GetType("System.Int32"));

            // set IL local V_0 to 0...
            alcILG.Emit(OpCodes.Ldc_I4_0);
            alcILG.Emit(OpCodes.Stloc_0);

            // get method for displaying integers...
            Type[] argTypes = { typeof(int) };
            writeIntMethod = typeof(Console).GetMethod(
              "WriteLine",
              argTypes
            );
        }

        private void doAddStatement(string arg)
        {
            alcILG.Emit(OpCodes.Ldloc_0);
            alcILG.Emit(OpCodes.Ldc_I4, Int32.Parse(arg));
            alcILG.Emit(OpCodes.Add);
            alcILG.Emit(OpCodes.Stloc_0);
        }

        private void doSubStatement(string arg)
        {
            alcILG.Emit(OpCodes.Ldloc_0);
            alcILG.Emit(OpCodes.Ldc_I4, Int32.Parse(arg));
            alcILG.Emit(OpCodes.Sub);
            alcILG.Emit(OpCodes.Stloc_0);
        }

        private void doPrintStatement()
        {
            alcILG.Emit(OpCodes.Ldloc_0);
            alcILG.Emit(OpCodes.Call, writeIntMethod);
        }

        private void doResetStatement()
        {
            alcILG.Emit(OpCodes.Ldc_I4_0);
            alcILG.Emit(OpCodes.Stloc_0);
        }

        private void save()
        {
            alcILG.Emit(OpCodes.Ret); // emit return statement
            alcCls.CreateType(); // create our new type
            Console.WriteLine("Writing " + outFile);
            alcAsm.Save(outFile); // save the assembly
        }

        private string inFile;
        private string outFile;

        private AssemblyBuilder alcAsm;
        private ModuleBuilder alcMod;
        private TypeBuilder alcCls;
        private ILGenerator alcILG;

        private MethodInfo writeIntMethod;
    }
}