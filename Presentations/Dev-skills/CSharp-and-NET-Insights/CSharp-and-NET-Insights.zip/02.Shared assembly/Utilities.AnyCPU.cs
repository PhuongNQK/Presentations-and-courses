﻿using System.Reflection;

[assembly: AssemblyVersion("1.0.0.0")]

namespace Demo.CSLib
{
	public static class Utilities
	{
		public static string Greet(string name)
		{
			return "Hello " + name;
		}
	}

	public static class Utils
	{
		public static string Greet(string name)
		{
			return "Hello " + name;
		}
	}
}