﻿Namespace Demo.VBLib
	Public Module Utilities
		Public Function Greet(ByVal name As String) As String
			Greet = "Hello " & name
		End Function
	End Module

	Public NotInheritable Class Utils
		Public Shared Function Greet(ByVal name As String) As String
			Greet = "Hello " & name
		End Function
	End Class
End Namespace